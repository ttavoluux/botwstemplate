let handler = async (m, { usedPrefix }) => {
try {
delete global.chatgpt.data.users[m.sender]  
m.reply(`*[❗] 𝙎𝙀 𝙀𝙇𝙄𝙈𝙄𝙉𝙊 𝘾𝙊𝙉 𝙀́𝙓𝙄𝙏𝙊 𝙀𝙇 𝙃𝙄𝙎𝙏𝙊𝙍𝙄𝘼𝙇 𝘿𝙀 𝙈𝙀𝙉𝙎𝘼𝙅𝙀𝙎 𝙀𝙉𝙏𝙍𝙀 𝙐𝙎𝙏𝙀𝘿 𝙔 𝘾𝙃𝘼𝙏𝙂𝙋𝙏 (𝙄𝘼) 𝙍𝙀𝘾𝙐𝙀𝙍𝘿𝙀 𝙌𝙐𝙀 𝙋𝙐𝙀𝘿𝙀 𝙐𝙏𝙄𝙇𝙄𝙕𝘼𝙍 𝙀𝙎𝙏𝙀 𝘾𝙊𝙈𝘼𝙉𝘿𝙊 𝘾𝙐𝘼𝙉𝘿𝙊 𝙏𝙀𝙉𝙂𝘼 𝘼𝙇𝙂𝙐𝙉 𝙀𝙍𝙍𝙊𝙍 𝙀𝙉 𝙀𝙇 𝘾𝙊𝙈𝘼𝙉𝘿𝙊 ${usedPrefix}ia2*`)    
} catch (error1) {   
console.log(error1)
throw `${lenguajeGB['smsAvisoFG']()}𝙀𝙍𝙍𝙊𝙍, 𝙑𝙐𝙀𝙇𝙑𝘼 𝘼 𝙄𝙉𝙏𝙀𝙉𝙏𝘼𝙍𝙇𝙊`   
}} 
handler.command = ['delchatgpt']
export default handler
