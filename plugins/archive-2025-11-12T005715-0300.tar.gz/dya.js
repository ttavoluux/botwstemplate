// import { sticker } from '../lib/sticker.js'
// //let handler = m => m
//
// let handler = async function (m, {conn, command, text, participants}) {
//
// let users = participants.map(u => conn.decodeJid(u.id))
//
// let picture = './media/menus/tzz/img14.jpg'
// let picture1 = './media/menus/tzz/img15.jpg'
//
// let chat = global.db.data.chats[m.chat]
//
//
// if((m.sender.split`@`[0] == '5215614236722') || (m.sender.split`@`[0] == '13137883665')){
// conn.sendMessage(m.chat, { text: '*❤ 𝐀𝐫𝐥𝐞𝐭𝐭𝐞 𝐚𝐧𝐝 𝐃𝐢𝐨𝐬𝐚 ❤*', mentions: users })
//
// let stiker = await sticker(imagen14, false, global.packname, global.author)
// this.sendFile(m.chat, stiker, 'sticker.webp', null, m, false, {
// contextInfo: { externalAdReply: { title: '❤ 𝐀𝐫𝐥𝐞𝐭𝐭𝐞 𝐚𝐧𝐝 𝐃𝐢𝐨𝐬𝐚 ❤', body: '❤', sourceUrl: `https://www.instagram.com/the_cazeriogirls?igsh=MTVsd3dqNXVwM3lwNg==`, thumbnail: imagen15}}})
//
// return !0 }else{
//
//
// conn.sendMessage(m.chat, { text: '*Exclusive : // Arletsita <3 ❤️🐈‍⬛; 💕 DEOS🦋*' })
// }
//
//
// }
// handler.command = /^(d&a|a&d|minovia111)$/i
// export default handler
//
//
// /*let teks = ' *⚠️ Este es un comando exclusivo*'
//
//
//
// let stiker = await sticker(imagen1, false, global.packname, global.author)
// this.sendFile(m.chat, stiker, 'sticker.webp', null, m, false, {
// contextInfo: { externalAdReply: { title: '🐈‍⬛ 𝑨𝒓𝒍𝒆𝒕𝒔𝒊𝒕𝒂 𝑩𝒐𝒕 ❤', body: '𝑨𝒓𝒍𝒆𝒕𝒔𝒊𝒕𝒂', sourceUrl: `https://www.instagram.com/arlenny.mx?igsh=MWNodzBweXUzY3hrbg==`, thumbnail: imagen2}}})
// //texto = texto2
// //texto3='*!'
// //texto4='!*'
//
// teks = `*❤Hola mi creadora* \n*@${m.sender.split`@`[0]}*`
// }
// let pesan = args.join` `
// //let oi = `ღ ${lenguajeGB['smsAddB5']()} ${pesan}`
//
//
// //conn.sendMessage(m.chat, { text: teks, mentions: [m.sender] }, )
// }
// handler.command = /^(d&a|a&d|minovia)$/i
// //handler.admin = false
// handler.group = true
// handler.botAdmin = true
// export default handler*/